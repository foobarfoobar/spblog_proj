class Bookmark < ActiveRecord::Base
  validates :title, :url, presence: true #pflichtfelder in der db
end
