class User < ActiveRecord::Base
  has_secure_password #Methoden zum Speichern, Validieren des PW & der PW-Wiederholung, Authentifizierungsfklt.
  
  validates :email, format: /\A([\A@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i, uniqueness: true
  # attr_accessible :email, :password, :password_confirmation
end
