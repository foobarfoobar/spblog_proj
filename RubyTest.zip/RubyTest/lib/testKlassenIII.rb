class Produkt
  attr_accessor :name, :preis
  
  @@anzahl = 0;#Klassenvariable
  
  def initialize(bez, preis)
    @name = bez
    @preis = preis
    @@anzahl += 1
  end
  
  def self.anzahl#Klassenmethode
    @@anzahl
  end
  
  # Ueberschreiben Operator '+'
  #@param produkt [Object] the Produkt after the '+' from which to add the preis
  def +(produkt)
    return @preis + produkt.preis
  end
  
  def orequal
    vorname    = "Richard"
   # bar = vorname.to_sym
    vorname  ||= "Schmitz" # vorname bleibt "Richard"
    nachname ||= "Schmitz" # nachname war bislang nil, deshalb jetzt "Schmitz"
    puts "Vorname: #{vorname}, Nachname: #{nachname}"
    return vorname, nachname
  end
  
end