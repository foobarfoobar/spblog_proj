liste = ["Foo", "Bar", "Qwerzt"]
for i in liste do
  puts i
end

liste.each do |k|
  puts k
end 

5.times do
  print "*"
end

foo = 2
bar = 5
puts
while foo < bar
  foo += 1
  print "x"
end

foo = 0
puts
until foo > bar
  foo += 1
  print "y"
end