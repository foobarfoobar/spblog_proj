class MegaGreeter
  attr_accessor :names
  # Erzeuge das Objekt
  def initialize(names = "Welt")
    @names = names
  end

  # Sag Hallo zu allen
  def sag_hallo
    if @names.nil?
      puts "..."
    elsif @names.respond_to?("each")
      # @names ist eine Liste, durchlaufe sie!
      @names.each do |name|
        puts "Hallo, #{name}!"
      end
    else
      puts "Hallo, #{@names}!"
    end
  end

  # Sag Tschuess zu allen
  def sag_tschuess
    if @names.nil?
      puts "..."
    elsif @names.respond_to?("join")
      # Verbinde die Listenelemente mit einem Komma
      puts "Tschuess, #{@names.join(", ")}, bis bald!"
    else
      puts "Tschuess, #{@names}, bis bald!"
    end
  end

end

if __FILE__ == $0#__FILE__ ist die magische Variable, die den Namen der gerade benutzen Datei als Wert hat,
  # während $0 der Name der Datei ist, mit dem das Programm gestartet wurde.
  # Die oben angegebene Anweisung besagt also “Wenn diese Datei die Haupt-Programmdatei ist …”.
  # Dies erlaubt es, eine Datei als Bibliothek (“library”) zu benutzen und in diesem Zusammenhang keinen Code
  # auszuführen, aber wenn die Datei als ausführbare Datei benutzt wird, wird der Code ausgeführt
  
  # Aendere den Namen in "Maximilian"
  mg.names = "Maximilian"
  mg.sag_hallo
  mg.sag_tschuess

  # Aendere den Namen in ein Array von Namen
  mg.names = ["Albert", "Bianca", "Carl-Heinz",
    "David", "Engelbert"]
  mg.sag_hallo
  mg.sag_tschuess

  # Aendere in nil
  mg.names = nil
mg.sag_hallo
mg.sag_tschuess
else
  puts __FILE__ + " ungleich " + $0
end