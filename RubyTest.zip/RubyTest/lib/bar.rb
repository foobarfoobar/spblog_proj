class Card
  attr_accessor :foo, :bar
  def initialize(f, b)
    @bar = b
    @foo = f
  end
end