class MyClass
  attr_accessor :items
  def initialize(ary=[])
    @items = ary
  end

  def each
    @items.each do |item|
      yield item #haengt item an die each-Variable |var|, wo Methode gecallt wird
                #yield heisst Inhalt, also der Inhalt der Schleife wird ausgegeben
    end
  end
end