#Tests dynamic params and related stuff
class DynParam
  #Takes the values and computes <i>min</i> and <i>max</i>
  #@param werte_liste {Array} the values
  def werte (*werte_liste)
    @max = werte_liste.max
    @min = werte_liste.min
    @liste = werte_liste
  end

  #max wert
  #@return [Fixnum] the <b>max</b> of <i>werte_liste</i>
  def max_temp
    @max
  end

  #min wert
  #@return [Fixnum] the <b>min</b> of <i>werte_liste</i>
  def min_temp
    @min
  end

  #Shuffles the list
  #@return [Array] a shuffled representation of <i>werte_liste</i>
  def shuffle
    @liste.shuffle!
  end

  def werte_hash_1(values={})
#    ztrewq = values.symbolize_keys #http://stackoverflow.com/questions/16576477/how-do-functions-use-hash-arguments-in-ruby
    qwertz = values[:laenge] * values[:breite] * values[:hoehe]
    return qwertz
  end

  def werte_hash_2(gewicht, values)
    return (values[:laenge] * values[:breite] * values[:hoehe]) * gewicht
  end
  
  # def bar(a, *b, **c)
    # [a, b, c]
  # end
#   
  # def my_method(**options)
    # puts options.inspect
  # end

  # def werte_hash_3(gewicht, values={}, noch_was) funzt nicht
    # return (values[:laenge] * values[:breite] * values[:hoehe]) * gewicht
  # end

end